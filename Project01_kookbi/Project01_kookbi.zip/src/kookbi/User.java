package kookbi;

public class User {
	public static void main(String[] args) {
		new Managements().view();
		
		
		
	}
}
